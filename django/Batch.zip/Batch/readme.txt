**** Better shortcut ****

1 - *(in myEnvironments)* <activate>   source djangoEnv/bin/activate
2 - Cd into django/
3 - bash Batch/create_django.sh “your project name”
4 - Cd into “your project name” / apps
5 - bash ../../Batch/create_django_app.sh “nameOFyour app”

**** END ****
